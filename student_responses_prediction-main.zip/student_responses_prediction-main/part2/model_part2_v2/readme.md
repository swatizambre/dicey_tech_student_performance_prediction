To download the model please click this link: https://drive.google.com/file/d/1XtnFi2T7JYJnCfwmucYX4oVQuKprx_TA/view?usp=drive_link
