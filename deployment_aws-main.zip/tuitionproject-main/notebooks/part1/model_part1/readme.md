To download the model please click this link: https://drive.google.com/file/d/1sjHW_j7m6m0W0wb9tEpBoLDlWcRioG2a/view?usp=drive_link
